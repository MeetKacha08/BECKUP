﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class ReviewController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public ReviewController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetAllReview()
        {
            List<ReviewModel> Review = new List<ReviewModel>();
            HttpResponseMessage response = _client.GetAsync("Review").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Review = JsonConvert.DeserializeObject<List<ReviewModel>>(data);
            }
            return View(Review);
        }

        public IActionResult InsertReview()
        {
            return View("InsertUpdateReview", new ReviewModel());
        }

        [HttpPost]
        public IActionResult InsertReview(ReviewModel Review)
        {
            string data = JsonConvert.SerializeObject(Review);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("Review", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Review added successfully!";
            else
                TempData["Message"] = "Failed to add Review.";

            return RedirectToAction("GetAllReview");
        }

        public IActionResult Edit(int ReviewID)
        {
            ReviewModel Review = new ReviewModel();
            HttpResponseMessage response = _client.GetAsync($"Review/{ReviewID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Review = JsonConvert.DeserializeObject<ReviewModel>(data);
            }
            return View("InsertUpdateReview", Review);
        }

        [HttpPost]
        public IActionResult UpdateReview(ReviewModel Review)
        {
            string data = JsonConvert.SerializeObject(Review);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"Review/{Review.ReviewID}", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Review updated successfully!";
            else
                TempData["Message"] = "Failed to update Review.";

            return RedirectToAction("GetAllReview");
        }

        public IActionResult Delete(int ReviewID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"Review/ {ReviewID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Review deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete Review.";

            return RedirectToAction("GetAllReview");
        }
    }
}
