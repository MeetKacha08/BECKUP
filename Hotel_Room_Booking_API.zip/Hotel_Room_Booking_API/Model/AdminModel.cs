﻿using System.Numerics;

namespace Hotel_Room_Booking_API.Model
{
    public class AdminModel
    {
        public int AdminID { get; set; }
        public string AdminName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
    }
}
