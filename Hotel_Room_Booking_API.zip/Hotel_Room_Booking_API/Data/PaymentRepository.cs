﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Hotel_Room_Booking_API.Data
{
    public class PaymentRepository
    {
        private readonly string _connectionString;


        public PaymentRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<PaymentModel> SelectAll()
        {
            var p = new List<PaymentModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Payment_SelectAll", conn)
                {

                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    p.Add(new PaymentModel
                    {
                        PaymentID = Convert.ToInt32(reader["PaymentID"]),
                        BookingID = Convert.ToInt32(reader["BookingID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        TAX = Convert.ToInt32(reader["TAX"]),
                        TotalAmount = Convert.ToInt32(reader["TotalAmount"]),
                        PaymentStatus = Convert.ToBoolean(reader["PaymentStatus"]),
                        PaymentDetails = reader["PaymentDetails"].ToString(),
                        PaymentType = reader["PaymentType"].ToString()
                    });
                }
            }
            return p;
        }

        public PaymentModel SelectByPK(int PaymentID)

        {

            PaymentModel p = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Payment_SelectByPK", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@PaymentID", PaymentID);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    p = new PaymentModel
                    {
                        PaymentID = Convert.ToInt32(reader["PaymentID"]),
                        BookingID = Convert.ToInt32(reader["BookingID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        TAX = Convert.ToInt32(reader["TAX"]),
                        TotalAmount = Convert.ToInt32(reader["TotalAmount"]),
                        PaymentStatus = Convert.ToBoolean(reader["PaymentStatus"]),
                        PaymentDetails = reader["PaymentDetails"].ToString(),
                        PaymentType = reader["PaymentType"].ToString()
                    };

                }

            }
            return p;
        }

        public bool InsertPayment(PaymentModel payment)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Payment_Insert", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@BookingID", payment.BookingID);
                cmd.Parameters.AddWithValue("@UserID", payment.UserID);
                cmd.Parameters.AddWithValue("@PaymentType", payment.PaymentType);
                cmd.Parameters.AddWithValue("@PaymentStatus", payment.PaymentStatus);
                cmd.Parameters.AddWithValue("@TAX", payment.TAX);
                cmd.Parameters.AddWithValue("@TotalAmount", payment.TotalAmount);
                cmd.Parameters.AddWithValue("@PaymentDetails", payment.PaymentDetails);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool UpdatePayment(PaymentModel payment)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Payment_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@PaymentID", payment.PaymentID);
                cmd.Parameters.AddWithValue("@BookingID", payment.BookingID);
                cmd.Parameters.AddWithValue("@UserID", payment.UserID);
                cmd.Parameters.AddWithValue("@PaymentType", payment.PaymentType);
                cmd.Parameters.AddWithValue("@PaymentStatus", payment.PaymentStatus);
                cmd.Parameters.AddWithValue("@TAX", payment.TAX);
                cmd.Parameters.AddWithValue("@TotalAmount", payment.TotalAmount);
                cmd.Parameters.AddWithValue("@PaymentDetails", payment.PaymentDetails);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool DeletePayment(int PaymentID)

        {

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Payment_Delete", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@PaymentID", PaymentID);

                conn.Open();
                int rowAffected = cmd.ExecuteNonQuery();
                return rowAffected > 0;
            }
        }
    }
}
