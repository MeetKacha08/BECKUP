﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Hotel_Room_Booking_API.Data
{
    public class UserRepository
    {
        private readonly string _connectionString;

        public UserRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<UserModel> GetAllUsers()
        {
            var users = new List<UserModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Users_SelectAll", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new UserModel
                        {
                            UserId = Convert.ToInt32(reader["UserID"]),
                            UserName = reader["UserName"].ToString(),
                            ProfileImage = reader["ProfileImage"].ToString(),
                            Email = reader["Email"].ToString(),
                            Password = reader["Password"].ToString(),
                            ContactNo = reader["ContactNo"].ToString(),
                            Address = reader["Address"].ToString(),
                            IDProofName = reader["IDProofName"].ToString(),
                            IDProofNumber = reader["IDProofNumber"].ToString()
                        });
                    }
                }
            }
            return users;
        }

        public UserModel GetUserById(int userId)
        {
            UserModel user = null;
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Users_SelectByPK", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserID", userId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        user = new UserModel
                        {
                            UserId = Convert.ToInt32(reader["UserID"]),
                            UserName = reader["UserName"].ToString(),
                            ProfileImage = reader["ProfileImage"].ToString(),
                            Email = reader["Email"].ToString(),
                            Password = reader["Password"].ToString(),
                            ContactNo = reader["ContactNo"].ToString(),
                            Address = reader["Address"].ToString(),
                            IDProofName = reader["IDProofName"].ToString(),
                            IDProofNumber = reader["IDProofNumber"].ToString()
                        };
                    }
                }
            }
            return user;
        }

        public bool InsertUser(UserModel user)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Users_Insert", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@ProfileImage", user.ProfileImage ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                cmd.Parameters.AddWithValue("@Password", user.Password);  // Ensure Password is passed
                cmd.Parameters.AddWithValue("@ContactNo", user.ContactNo);
                cmd.Parameters.AddWithValue("@Address", user.Address);
                cmd.Parameters.AddWithValue("@IDProofName", user.IDProofName);
                cmd.Parameters.AddWithValue("@IDProofNumber", user.IDProofNumber);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool UpdateUser(UserModel user)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Users_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserID", user.UserId);
                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@ProfileImage", user.ProfileImage ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                cmd.Parameters.AddWithValue("@Password", user.Password);
                cmd.Parameters.AddWithValue("@ContactNo", user.ContactNo);
                cmd.Parameters.AddWithValue("@Address", user.Address);
                cmd.Parameters.AddWithValue("@IDProofName", user.IDProofName);
                cmd.Parameters.AddWithValue("@IDProofNumber", user.IDProofNumber);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool DeleteUser(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Users_Delete", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserID", id);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}