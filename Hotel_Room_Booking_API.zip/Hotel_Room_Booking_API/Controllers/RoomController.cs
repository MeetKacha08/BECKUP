﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private readonly RoomRepository _roomRepository;

        public RoomController(RoomRepository roomRepository)
        {
            _roomRepository = roomRepository;
        }

        [HttpGet]

        public IActionResult GetRoom()
        {
            var ro = _roomRepository.SelectAll();
            return Ok(ro);
        }

        [HttpGet("{id}")]

        public IActionResult GetRoomById(int id)
        {

            var r = _roomRepository.SelectByPK(id);

            if (r == null)

            {

                return NotFound();

            }

            return Ok(r);

        }

        [HttpPost]
        public IActionResult InsertRoom([FromBody] RoomModel room)
        {
            if (room == null) return BadRequest("Invalid room data.");
            if (!_roomRepository.InsertRoom(room)) return StatusCode(StatusCodes.Status500InternalServerError, "Room insertion failed.");
            return CreatedAtAction(nameof(GetRoomById), new { id = room.RoomID }, room);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateRoom([FromBody] RoomModel id)
        {
            if (id == null) return BadRequest("Invalid user data.");
            if (!_roomRepository.UpdateRoom(id)) return StatusCode(StatusCodes.Status500InternalServerError, "Room update failed.");
            return NoContent();
        }

        [HttpDelete("{id}")]

        public IActionResult DeleteRoom(int id)
        {
            var isDeleted = _roomRepository.DeleteRoom(id);

            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
