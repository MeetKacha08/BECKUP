﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly CategoryRepository _categoryRepository;

        public CategoryController(CategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [HttpGet]

        public IActionResult GetCategory()
        {
            var ct = _categoryRepository.SelectAll();
            return Ok(ct);
        }

        [HttpGet("{id}")]

        public IActionResult GetCategoryById(int id)
        {

            var cat = _categoryRepository.SelectByPK(id);

            if (cat == null)

            {

                return NotFound();

            }

            return Ok(cat);

        }

        [HttpPost]
        public IActionResult InsertCategory([FromBody] CategoryModel category)
        {
            if (category == null) return BadRequest("Invalid category data.");
            if (!_categoryRepository.InsertCategory(category)) return StatusCode(StatusCodes.Status500InternalServerError, "User insertion failed.");
            return CreatedAtAction(nameof(GetCategoryById), new { id = category.CategoryID }, category);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCategory([FromBody] CategoryModel id)
        {
            if (id == null) return BadRequest("Invalid category data.");
            if (!_categoryRepository.UpdateCategory(id)) return StatusCode(StatusCodes.Status500InternalServerError, "Category update failed.");
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCategory(int id)
        {
            if (!_categoryRepository.DeleteCategory(id)) return Ok();
            return NoContent();
        }
    }
}
