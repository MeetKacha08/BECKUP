﻿namespace Hotel_Room_Booking_API.Model
{
    public class CategoryModel
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
    }
}
