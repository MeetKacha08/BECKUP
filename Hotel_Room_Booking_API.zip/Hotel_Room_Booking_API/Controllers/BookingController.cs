﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly BookingRepository _bookingRepository;

        public BookingController(BookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }

        [HttpGet]

        public IActionResult GetBooking()
        {
            var b = _bookingRepository.SelectAll();
            return Ok(b);
        }

        [HttpGet("{id}")]

        public IActionResult GetBookingById(int id)
        {

            var b = _bookingRepository.SelectByPK(id);

            if (b == null)

            {

                return NotFound();

            }

            return Ok(b);

        }

        [HttpPost]
        public IActionResult InsertBooking([FromBody] BookingModel booking)
        {
            if (booking == null) return BadRequest("Invalid booking data.");
            if (!_bookingRepository.InsertBooking(booking)) return StatusCode(StatusCodes.Status500InternalServerError, "Booking insertion failed.");
            return CreatedAtAction(nameof(GetBookingById), new { id = booking.BookingID }, booking);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateBooking([FromBody] BookingModel id)
        {
            if (id == null) return BadRequest("Invalid booking data.");
            if (!_bookingRepository.UpdateBooking(id)) return StatusCode(StatusCodes.Status500InternalServerError, "Booking update failed.");
            return NoContent();
        }

        [HttpDelete("{id}")]

        public IActionResult DeleteBooking(int id)
        {
            var isDeleted = _bookingRepository.DeleteBooking(id);

            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
