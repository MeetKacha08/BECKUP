﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Hotel_Room_Booking_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;


namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserRepository _userRepository;
        private readonly CloudinaryService _cloudinaryService;

        public UserController(UserRepository userRepository, CloudinaryService cloudinaryService)
        {
            _userRepository = userRepository;
            _cloudinaryService = cloudinaryService;

        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            return Ok(_userRepository.GetAllUsers());
        }

        [HttpGet("{id}")]
        public IActionResult GetUserById(int id)
        {
            var user = _userRepository.GetUserById(id);
            if (user == null) return NotFound();
            return Ok(user);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            if (!_userRepository.DeleteUser(id)) return Ok();
            return NoContent();
        }

        [HttpPost]
        public async Task<IActionResult> InsertUser([FromForm] UserModel user, IFormFile profileImageFile)
        {
            if (user == null) return BadRequest("Invalid user data.");

            if (profileImageFile != null)
            {
                user.ProfileImage = await _cloudinaryService.UploadImageAsync(profileImageFile);
            }

            if (!_userRepository.InsertUser(user)) return StatusCode(StatusCodes.Status500InternalServerError, "User insertion failed.");
            return CreatedAtAction(nameof(GetUserById), new { id = user.UserId }, user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromForm] UserModel user, IFormFile profileImageFile)
        {
            if (user == null || user.UserId != id) return BadRequest("Invalid user data.");

            if (profileImageFile != null)
            {
                user.ProfileImage = await _cloudinaryService.UploadImageAsync(profileImageFile);
            }

            if (!_userRepository.UpdateUser(user)) return StatusCode(StatusCodes.Status500InternalServerError, "User update failed.");
            return NoContent();
        }

        //is active or deactiv code
        //[HttpPut("ChangeStatus/{id}")]
        //public async Task<IActionResult> ChangeUserStatus(int id, [FromBody] bool isActive)
        //{
        //    var user = await _userRepository.User.FindAsync(id);
        //    if (user == null)
        //    {
        //        return NotFound(new { message = "User not found" });
        //    }

        //    user.IsActive = isActive;
        //    await _userRepository.SaveChangesAsync();

        //    return Ok(new { message = $"User {(isActive ? "Activated" : "Deactivated")} Successfully" });
        //}
    }
}
