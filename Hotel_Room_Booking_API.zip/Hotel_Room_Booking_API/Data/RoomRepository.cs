﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Hotel_Room_Booking_API.Data
{
    public class RoomRepository
    {
        private readonly string _connectionString;

        public RoomRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<RoomModel> SelectAll()
        {
            var r = new List<RoomModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Room_SelectAll", conn)
                {

                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    r.Add(new RoomModel
                    {
                        RoomID = Convert.ToInt32(reader["RoomID"]),
                        CategoryID = Convert.ToInt32(reader["CategoryID"]),
                        RoomPrice = Convert.ToInt32(reader["RoomPrice"]),
                        RoomStatus = Convert.ToBoolean(reader["RoomStatus"]),
                    });
                }
            }
            return r;
        }

        public RoomModel SelectByPK(int RoomID)

        {

            RoomModel r = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Room_SelectByPK", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@RoomID", RoomID);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    r = new RoomModel
                    {
                        RoomID = Convert.ToInt32(reader["RoomID"]),
                        CategoryID = Convert.ToInt32(reader["CategoryID"]),
                        RoomPrice = Convert.ToInt32(reader["RoomPrice"]),
                        RoomStatus = Convert.ToBoolean(reader["RoomStatus"])
                    };

                }

            }
            return r;
        }

        public bool InsertRoom(RoomModel room)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Room_Insert", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@CategoryID", room.CategoryID);
                cmd.Parameters.AddWithValue("@RoomPrice", room.RoomPrice);
                cmd.Parameters.AddWithValue("@RoomStatus", room.RoomStatus);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool UpdateRoom(RoomModel room)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Room_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@RoomID", room.RoomID);
                cmd.Parameters.AddWithValue("@CategoryID", room.CategoryID);
                cmd.Parameters.AddWithValue("@RoomPrice", room.RoomPrice);
                cmd.Parameters.AddWithValue("@RoomStatus", room.RoomStatus);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool DeleteRoom(int RoomID)

        {

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Room_Delete", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@RoomID", RoomID);

                conn.Open();
                int rowAffected = cmd.ExecuteNonQuery();
                return rowAffected > 0;
            }
        }

    }
}
