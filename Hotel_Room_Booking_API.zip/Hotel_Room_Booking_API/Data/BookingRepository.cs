﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Hotel_Room_Booking_API.Data
{
    public class BookingRepository
    {
        private readonly string _connectionString;

        public BookingRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<BookingModel> SelectAll()
        {
            var b = new List<BookingModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Booking_SelectAll", conn)
                {

                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    b.Add(new BookingModel
                    {
                        BookingID = Convert.ToInt32(reader["BookingID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        RoomID = Convert.ToInt32(reader["RoomID"]),
                        CategoryID = Convert.ToInt32(reader["CategoryID"]),
                        Amount = Convert.ToInt32(reader["Amount"]),
                    });
                }
            }
            return b;
        }

        public BookingModel SelectByPK(int BookingID)

        {

            BookingModel b = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Booking_SelectByPK", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@BookingID", BookingID);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    b = new BookingModel
                    {
                        BookingID = Convert.ToInt32(reader["BookingID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        RoomID = Convert.ToInt32(reader["RoomID"]),
                        CategoryID = Convert.ToInt32(reader["CategoryID"]),
                        Amount = Convert.ToInt32(reader["Amount"]),
                    };

                }

            }
            return b;
        }

        public bool InsertBooking(BookingModel booking)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Booking_Insert", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserID", booking.UserID);
                cmd.Parameters.AddWithValue("@RoomID", booking.RoomID);
                cmd.Parameters.AddWithValue("@CategoryID", booking.CategoryID);
                cmd.Parameters.AddWithValue("@CheckInDate", booking.CheckInDate);
                cmd.Parameters.AddWithValue("@CheckOutDate", booking.CheckOutDate);
                cmd.Parameters.AddWithValue("@Amount", booking.Amount);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool UpdateBooking(BookingModel booking)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Booking_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@BookingID", booking.BookingID);
                cmd.Parameters.AddWithValue("@UserID", booking.UserID);
                cmd.Parameters.AddWithValue("@RoomID", booking.RoomID);
                cmd.Parameters.AddWithValue("@CategoryID", booking.CategoryID);
                cmd.Parameters.AddWithValue("@CheckInDate", booking.CheckInDate);
                cmd.Parameters.AddWithValue("@CheckOutDate", booking.CheckOutDate);
                cmd.Parameters.AddWithValue("@Amount", booking.Amount);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool DeleteBooking(int BookingID)

        {

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Booking_Delete", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@BookingID", BookingID);

                conn.Open();
                int rowAffected = cmd.ExecuteNonQuery();
                return rowAffected > 0;
            }
        }
    }
}
