﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class UserController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public UserController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetUser()
        {
            List<UserModel> users = new List<UserModel>();
            HttpResponseMessage response = _client.GetAsync("User").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                users = JsonConvert.DeserializeObject<List<UserModel>>(data);
            }
            return View(users);
        }

        public IActionResult InsertUser()
        {
            return View("InsertUpdateUser", new UserModel());
        }

        [HttpPost]
        public IActionResult InsertUser(UserModel user, IFormFile profileImageFile)
        {
           
            string data = JsonConvert.SerializeObject(user);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("User", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "User added successfully!";
            else
                TempData["Message"] = "Failed to add user.";

            return RedirectToAction("GetUser");

            if (profileImageFile != null && profileImageFile.Length > 0)
            {
                // Convert the file to a base64 string (or upload to Cloudinary directly)
                using (var ms = new MemoryStream())
                {
                    profileImageFile.CopyTo(ms);
                    var fileBytes = ms.ToArray();
                    string base64String = Convert.ToBase64String(fileBytes);
                    user.ProfileImage = $"data:image/jpeg;base64,{base64String}";
                }
            }
        }


        public IActionResult Edit(int UserID)
        {
            UserModel user = new UserModel();
            HttpResponseMessage response = _client.GetAsync($"User/{UserID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<UserModel>(data);
            }
            return View("InsertUpdateUser", user);
        }

        
        [HttpPost]
        public IActionResult UpdateUser(UserModel user, IFormFile profileImageFile)
        {
            if (user == null)
            {
                TempData["Message"] = "Invalid user data.";
                return RedirectToAction("GetUser");
            }

            // Handle file upload if a new file is provided
            if (profileImageFile != null && profileImageFile.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    profileImageFile.CopyTo(ms);
                    var fileBytes = ms.ToArray();
                    string base64String = Convert.ToBase64String(fileBytes);
                    user.ProfileImage = $"data:image/jpeg;base64,{base64String}"; // Store as base64 string
                }
            }

            // Serialize the user object and send it to the API
            string data = JsonConvert.SerializeObject(user);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"User/{user.UserID}", content).Result;

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] = "User updated successfully!";
            }
            else
            {
                TempData["Message"] = "Failed to update user.";
            }

            return RedirectToAction("GetUser");
        }

        public IActionResult Delete(int UserID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"User/{UserID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "User deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete user.";

            return RedirectToAction("GetUser");
        }
    }
}