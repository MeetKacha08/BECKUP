﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class BookingController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public BookingController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetAllBooking()
        {
            List<BookingModel> Booking = new List<BookingModel>();
            HttpResponseMessage response = _client.GetAsync("Booking").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Booking = JsonConvert.DeserializeObject<List<BookingModel>>(data);
            }
            return View(Booking);
        }

        public IActionResult InsertBooking()
        {
            return View("InsertUpdateBooking", new BookingModel());
        }

        [HttpPost]
        public IActionResult InsertBooking(BookingModel Booking)
        {
            string data = JsonConvert.SerializeObject(Booking);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("Booking", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Booking added successfully!";
            else
                TempData["Message"] = "Failed to add Booking.";

            return RedirectToAction("GetAllBooking");
        }

        public IActionResult Edit(int BookingID)
        {
            BookingModel Booking = new BookingModel();
            HttpResponseMessage response = _client.GetAsync($"Booking/{BookingID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Booking = JsonConvert.DeserializeObject<BookingModel>(data);
            }
            return View("InsertUpdateBooking", Booking);
        }

        [HttpPost]
        public IActionResult UpdateBooking(BookingModel Booking)
        {
            string data = JsonConvert.SerializeObject(Booking);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"Booking/{Booking.BookingID}", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Booking updated successfully!";
            else
                TempData["Message"] = "Failed to update Booking.";

            return RedirectToAction("GetAllBooking");
        }

        public IActionResult Delete(int BookingID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"Booking/ {BookingID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Booking deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete Booking.";

            return RedirectToAction("GetAllBooking");
        }
    }
}
