﻿namespace Hotel_Room_Booking_API.Model
{
    public class RoomModel
    {
        public int RoomID { get; set; }
        public int CategoryID { get; set; }
        public float RoomPrice { get; set; }
        public bool RoomStatus { get; set; }
    }
}
