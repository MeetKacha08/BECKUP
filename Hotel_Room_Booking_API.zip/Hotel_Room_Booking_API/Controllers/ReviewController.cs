﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly ReviewRepository _reviewRepository;

        public ReviewController(ReviewRepository reviewRepository)
        {
            _reviewRepository = reviewRepository;
        }

        [HttpGet]

        public IActionResult GetReview()
        {
            var r = _reviewRepository.SelectAll();
            return Ok(r);
        }

        [HttpGet("{id}")]

        public IActionResult GetReviewById(int id)
        {

            var r = _reviewRepository.SelectByPK(id);

            if (r == null)

            {

                return NotFound();

            }

            return Ok(r);

        }

        [HttpPost]
        public IActionResult InsertReview([FromBody] ReviewModel review)
        {
            if (review == null) return BadRequest("Invalid review data.");
            if (!_reviewRepository.InsertReview(review)) return StatusCode(StatusCodes.Status500InternalServerError, "Review insertion failed.");
            return CreatedAtAction(nameof(GetReviewById), new { id = review.ReviewID }, review);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateReview([FromBody] ReviewModel id)
        {
            if (id == null) return BadRequest("Invalid review data.");
            if (!_reviewRepository.UpdateReview(id)) return StatusCode(StatusCodes.Status500InternalServerError, "Review update failed.");
            return NoContent();
        }

        [HttpDelete("{id}")]

        public IActionResult DeleteReview(int id)
        {
            var isDeleted = _reviewRepository.DeleteReview(id);

            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
