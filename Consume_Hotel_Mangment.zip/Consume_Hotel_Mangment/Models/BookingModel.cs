﻿namespace Consume_Hotel_Mangment.Models
{
    public class BookingModel
    {
        public int BookingID { get; set; }
        public int UserID { get; set; }
        public int RoomID { get; set; }
        public int CategoryID { get; set; }
        public DateTime CheckInDate { get; set; } =  DateTime.Now;
        public DateTime CheckOutDate { get; set; } = DateTime.Now;
        public float Amount { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public DateTime ModifiedDate { get; set; } = DateTime.Now;
    }
}
