﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Net;

namespace Hotel_Room_Booking_API.Data
{
    public class AdminRepository
    {
        private readonly string _connectionString;

        public AdminRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<AdminModel> SelectAll()
        {
            var a = new List<AdminModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Admin_SelectAll", conn)
                {

                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                
                while (reader.Read())
                {
                    a.Add(new AdminModel
                    {
                        AdminID = Convert.ToInt32(reader["AdminID"]),
                        AdminName = reader["AdminName"].ToString(),
                        Email = reader["Email"].ToString(),
                        ContactNo = reader["ContactNo"].ToString(),
                        Address = reader["Address"].ToString()
                    });
                }
            }
            return a;
        }
    }
}
