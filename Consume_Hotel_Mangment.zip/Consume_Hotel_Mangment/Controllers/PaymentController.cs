﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class PaymentController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public PaymentController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetAllPayment()
        {
            List<PaymentModel> payments = new List<PaymentModel>();
            HttpResponseMessage response = _client.GetAsync("Payment").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                payments = JsonConvert.DeserializeObject<List<PaymentModel>>(data);
            }
            return View(payments);
        }

        public IActionResult InsertPayment()
        {
            return View("InsertUpdatePayment", new PaymentModel());
        }

        [HttpPost]
        public IActionResult InsertPayment(PaymentModel payment)
        {
            string data = JsonConvert.SerializeObject(payment);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("Payment", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Payment added successfully!";
            else
                TempData["Message"] = "Failed to add Payment.";

            return RedirectToAction("GetAllPayment");
        }

        public IActionResult Edit(int PaymentID)
        {
            PaymentModel payment = new PaymentModel();
            HttpResponseMessage response = _client.GetAsync($"Payment/{PaymentID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                payment = JsonConvert.DeserializeObject<PaymentModel>(data);
            }
            return View("InsertUpdatePayment", payment);
        }

        [HttpPost]
        public IActionResult UpdatePayment(PaymentModel payment)
        {
            string data = JsonConvert.SerializeObject(payment);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"Payment/{payment.PaymentID}", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Payment updated successfully!";
            else
                TempData["Message"] = "Failed to update Payment.";

            return RedirectToAction("GetAllPayment");
        }

        public IActionResult Delete(int PaymentID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"Payment/ {PaymentID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Payment deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete Payment.";

            return RedirectToAction("GetAllPayment");
        }
    }
}
