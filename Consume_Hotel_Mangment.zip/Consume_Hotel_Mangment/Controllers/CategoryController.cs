﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class CategoryController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public CategoryController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetAllCategory()
        {
            List<CategoryModel> category = new List<CategoryModel>();
            HttpResponseMessage response = _client.GetAsync("Category").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                category = JsonConvert.DeserializeObject<List<CategoryModel>>(data);
            }
            return View(category);
        }

        public IActionResult InsertCategory()
        {
            return View("InsertUpdateCategory", new CategoryModel());
        }

        [HttpPost]
        public IActionResult InsertCategory(CategoryModel category)
        {
            string data = JsonConvert.SerializeObject(category);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("Category", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Category added successfully!";
            else
                TempData["Message"] = "Failed to add Category.";

            return RedirectToAction("GetAllCategory");
        }

        public IActionResult Edit(int CategoryID)
        {
            CategoryModel category = new CategoryModel();
            HttpResponseMessage response = _client.GetAsync($"Category/{CategoryID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                category = JsonConvert.DeserializeObject<CategoryModel>(data);
            }
            return View("InsertUpdateCategory", category);
        }

        [HttpPost]
        public IActionResult UpdateCategory(CategoryModel category)
        {
            string data = JsonConvert.SerializeObject(category);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"Category/{category.CategoryID}", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Category updated successfully!";
            else
                TempData["Message"] = "Failed to update Category.";

            return RedirectToAction("GetAllCategory");
        }

        public IActionResult Delete(int CategoryID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"Category/ {CategoryID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Category deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete Category.";

            return RedirectToAction("GetAllCategory");
        }
    }
}
