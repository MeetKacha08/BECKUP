﻿namespace Hotel_Room_Booking_API.Model
{
    public class ReviewModel
    {
        public int ReviewID { get; set; }
        public int UserID { get; set; }
        public int Rating { get; set; }
        public string Comments { get; set; }
    }
}
    