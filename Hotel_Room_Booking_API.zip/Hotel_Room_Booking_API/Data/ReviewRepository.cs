﻿using Hotel_Room_Booking_API.Model;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Hotel_Room_Booking_API.Data
{
    public class ReviewRepository
    {
        private readonly string _connectionString;


        public ReviewRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<ReviewModel> SelectAll()
        {
            var r = new List<ReviewModel>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Review_SelectAll", conn)
                {

                    CommandType = CommandType.StoredProcedure
                };
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    r.Add(new ReviewModel
                    {
                        ReviewID = Convert.ToInt32(reader["ReviewID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        Rating = Convert.ToInt32(reader["Rating"]),
                        Comments = reader["Comments"].ToString(),
                    });
                }
            }
            return r;
        }

        public ReviewModel SelectByPK(int ReviewID)

        {

            ReviewModel r = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Review_SelectByPK", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@ReviewID", ReviewID);

                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    r = new ReviewModel
                    {
                        ReviewID = Convert.ToInt32(reader["ReviewID"]),
                        UserID = Convert.ToInt32(reader["UserID"]),
                        Rating = Convert.ToInt32(reader["Rating"]),
                        Comments = reader["Comments"].ToString(),
                    };

                }

            }
            return r;
        }

        public bool InsertReview(ReviewModel review)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Review_Insert", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@UserID", review.UserID);
                cmd.Parameters.AddWithValue("@Rating", review.Rating);
                cmd.Parameters.AddWithValue("@Comments", review.Comments);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }


        public bool UpdateReview(ReviewModel review)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("PR_Review_Update", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@ReviewID", review.ReviewID);
                cmd.Parameters.AddWithValue("@UserID", review.UserID);
                cmd.Parameters.AddWithValue("@Rating", review.Rating);
                cmd.Parameters.AddWithValue("@Comments", review.Comments);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool DeleteReview(int ReviewID)

        {

            using (SqlConnection conn = new SqlConnection(_connectionString))

            {

                SqlCommand cmd = new SqlCommand("PR_Review_Delete", conn)

                {

                    CommandType = CommandType.StoredProcedure

                };

                cmd.Parameters.AddWithValue("@ReviewID", ReviewID);

                conn.Open();
                int rowAffected = cmd.ExecuteNonQuery();
                return rowAffected > 0;
            }
        }
    }
}

