﻿namespace Hotel_Room_Booking_API.Model
{
    public class PaymentModel
    {
        public int PaymentID { get; set; }
        public int BookingID { get; set; }
        public int UserID { get; set; }
        public float TAX { get; set; }
        public float TotalAmount { get; set; }
        public bool PaymentStatus { get; set; }
        public string PaymentDetails { get; set; }
        public string PaymentType { get; set; }
    }
}
