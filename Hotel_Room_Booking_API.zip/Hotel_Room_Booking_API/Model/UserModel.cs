﻿namespace Hotel_Room_Booking_API.Model
{
    public class UserModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string? ProfileImage { get; set; }
        public string Email { get; set; }
        public string? Password { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public string IDProofName { get; set; }
        public string IDProofNumber { get; set; }
        public bool IsActive { get; set; }
    }
}