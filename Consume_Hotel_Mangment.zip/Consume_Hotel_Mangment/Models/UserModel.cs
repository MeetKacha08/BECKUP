﻿namespace Consume_Hotel_Mangment.Models
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string? ProfileImage { get; set; }
        public string Email { get; set; }
        public string? Password { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public string IDProofName { get; set; }
        public string IDProofNumber { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public DateTime ModifiedDate { get; set; } = DateTime.Now;

        // Add this property for file upload (not mapped to the database)
        public IFormFile ProfileImageFile { get; set; }
        public string? ImagePath { get; set; }
    }
}
