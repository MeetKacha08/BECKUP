﻿using Hotel_Room_Booking_API.Data;
using Hotel_Room_Booking_API.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Room_Booking_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentRepository _paymentRepository;

        public PaymentController(PaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        [HttpGet]

        public IActionResult GetPayment()
        {
            var p = _paymentRepository.SelectAll();
            return Ok(p);
        }

        [HttpGet("{id}")]

        public IActionResult GetPaymentById(int id)
        {

            var p = _paymentRepository.SelectByPK(id);

            if (p == null)

            {

                return NotFound();

            }

            return Ok(p);

        }

        [HttpPost]
        public IActionResult InsertPayment([FromBody] PaymentModel payment)
        {
            if (payment == null) return BadRequest("Invalid payment data.");
            if (!_paymentRepository.InsertPayment(payment)) return StatusCode(StatusCodes.Status500InternalServerError, "Payment insertion failed.");
            return CreatedAtAction(nameof(GetPaymentById), new { id = payment.PaymentID }, payment);
        }

        [HttpPut("{id}")]
        public IActionResult UpdatePayment([FromBody] PaymentModel id)
        {
            if (id == null) return BadRequest("Invalid payment data.");
            if (!_paymentRepository.UpdatePayment(id)) return StatusCode(StatusCodes.Status500InternalServerError, "Payment update failed.");
            return NoContent();
        }

        [HttpDelete("{id}")]

        public IActionResult DeletePayment(int id)
        {
            var isDeleted = _paymentRepository.DeletePayment(id);

            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
