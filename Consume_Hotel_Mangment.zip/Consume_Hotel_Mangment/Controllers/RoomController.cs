﻿using Consume_Hotel_Mangment.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace Consume_Hotel_Mangment.Controllers
{
    public class RoomController : Controller
    {
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("https://localhost:44365/api/");

        public RoomController()
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        public IActionResult GetAllRoom()
        {
            List<RoomModel> Room = new List<RoomModel>();
            HttpResponseMessage response = _client.GetAsync("Room").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Room = JsonConvert.DeserializeObject<List<RoomModel>>(data);
            }
            return View(Room);
        }

        public IActionResult InsertRoom()
        {
            return View("InsertUpdateRoom", new RoomModel());
        }

        [HttpPost]
        public IActionResult InsertRoom(RoomModel Room)
        {
            string data = JsonConvert.SerializeObject(Room);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PostAsync("Room", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Room added successfully!";
            else
                TempData["Message"] = "Failed to add Room.";

            return RedirectToAction("GetAllRoom");
        }

        public IActionResult Edit(int RoomID)
        {
            RoomModel Room = new RoomModel();
            HttpResponseMessage response = _client.GetAsync($"Room/{RoomID}").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                Room = JsonConvert.DeserializeObject<RoomModel>(data);
            }
            return View("InsertUpdateRoom", Room);
        }

        [HttpPost]
        public IActionResult UpdateRoom(RoomModel Room)
        {
            string data = JsonConvert.SerializeObject(Room);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = _client.PutAsync($"Room/{Room.RoomID}", content).Result;

            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Room updated successfully!";
            else
                TempData["Message"] = "Failed to update Room.";

            return RedirectToAction("GetAllRoom");
        }

        public IActionResult Delete(int RoomID)
        {
            HttpResponseMessage response = _client.DeleteAsync($"Room/ {RoomID}").Result;
            if (response.IsSuccessStatusCode)
                TempData["Message"] = "Room deleted successfully!";
            else
                TempData["MessageNotDelete"] = "Failed to delete Room.";

            return RedirectToAction("GetAllRoom");
        }
    }
}
