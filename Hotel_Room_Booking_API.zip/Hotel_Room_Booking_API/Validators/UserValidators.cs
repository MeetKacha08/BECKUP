﻿using Hotel_Room_Booking_API.Model;
using FluentValidation;
namespace Hotel_Room_Booking_API.Validators
{
    public class UserValidators : AbstractValidator<UserModel>
    {
        public UserValidators()
        {
            RuleFor(x => x.UserName)
            .NotEmpty().WithMessage("Username is required.")
            .Length(3, 20).WithMessage("Username must be between 3 and 50 characters.");

            RuleFor(x => x.ProfileImage)
                .NotEmpty().WithMessage("Profile Image is Required.")
                .When(x => !string.IsNullOrEmpty(x.ProfileImage));

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required.")
                .Matches(@"^[^@\s]+@[^@\s]+\.[^@\s]+$")
                .EmailAddress().WithMessage("Invalid email format.");

            RuleFor(x => x.Password)
                .NotEmpty().WithMessage("Password is required.")
                .Length(6, 100).WithMessage("Password must be at least 6 characters long.")
                .Matches(@"[A-Z]").WithMessage("Password must contain at least one uppercase letter.")
                .Matches(@"[a-z]").WithMessage("Password must contain at least one lowercase letter.")
                .Matches(@"[0-9]").WithMessage("Password must contain at least one digit.")
                .Matches(@"[\W]").WithMessage("Password must contain at least one special character.");

            RuleFor(x => x.ContactNo)
                .NotEmpty().WithMessage("Contact number is required.")
                .Matches(@"^\+?\d{10,15}$").WithMessage("Contact number must be a valid phone number with 10 to 15 digits.");

            RuleFor(x => x.Address)
                .NotEmpty().WithMessage("Address is required.")
                .Length(5, 300).WithMessage("Address must be between 10 and 255 characters.");

            RuleFor(x => x.IDProofName)
                .NotEmpty().WithMessage("ID Proof name is required.")
                .Length(3, 100).WithMessage("ID Proof name must be between 3 and 100 characters.");

            RuleFor(x => x.IDProofNumber)
                .NotEmpty().WithMessage("ID Proof number is required.")
                .Matches(@"^\d{12}$").WithMessage("ID Proof number must be a 12-digit number.");

            RuleFor(x => x.IsActive)
                .NotNull().WithMessage("IsActive flag must be specified.");
        }
    }
}