﻿namespace Consume_Hotel_Mangment.Models
{
    public class ReviewModel
    {
        public int ReviewID { get; set; }
        public int UserID { get; set; }
        public int Rating { get; set; }
        public string Comments { get; set; }
        public DateTime ReviewDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
