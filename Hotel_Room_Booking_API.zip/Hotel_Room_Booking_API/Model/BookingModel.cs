﻿using Microsoft.Identity.Client;

namespace Hotel_Room_Booking_API.Model
{
    public class BookingModel
    {
        public int BookingID { get; set; }
        public int UserID { get; set; }
        public int RoomID { get; set; }
        public int CategoryID { get; set; }
        public DateOnly CheckInDate { get; set; }
        public DateOnly CheckOutDate { get; set; }
        public float Amount { get; set; }
    }
}
